#include "types.h"
#include "stat.h"
#include "user.h"

#define PG 4096

// Q2 test: lazy allocation + page fault counting
int
main(int argc, char *argv[])
{
  char *p;
  int start, pid;

  start = getfaults();
  p = sbrk(32 * PG);
  printf(1, "sbrk(32*4096) done, faults so far: %d\n", getfaults() - start);

  // touch 5 different pages, leave the others alone
  p[0 * PG] = 1;
  p[3 * PG] = 1;
  p[7 * PG] = 1;
  p[15 * PG] = 1;
  p[31 * PG] = 1;

  printf(1, "page faults handled: %d (expected 5)\n", getfaults() - start);

  // write to the same page again, should not fault
  p[3 * PG + 10] = 2;
  printf(1, "after rewriting page 3: %d\n", getfaults() - start);

  // now access beyond sz in a child, only the child should die
  pid = fork();
  if(pid == 0){
    char *bad = p + 32 * PG + 100;   // above the allocated size
    printf(1, "child: touching 0x%x\n", (int)bad);
    *bad = 1;
    printf(1, "child: this line should never be printed\n");
    exit();
  }
  wait();
  printf(1, "parent: still alive after child was killed\n");
  exit();
}
