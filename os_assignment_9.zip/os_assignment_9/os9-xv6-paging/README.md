# OS Assignment 9 - xv6 paging

Likhitha Vijaya Kumar, 2403MC05, IIT Patna
Course: Operating Systems (Prof. Ranjeet Ranjan Jha)

Base: mit-pdos/xv6-public (x86), commit eeb7b41.

## Layout

| folder | what |
|---|---|
| `q1_page_table/` | full xv6 tree with `vmprint()` syscall + `pttest.c` |
| `q2_lazy_alloc/` | full xv6 tree with lazy sbrk, page fault handler, `getfaults()` + `faulttest.c` |
| `q3_page_replacement/` | xv6 tree with `pagerepl.c` (FIFO / LRU) |
| `patches/` | `diff -u` of each folder against vanilla xv6 (shows exactly what changed) |
| `outputs/` | text output of Q3 |
| `screenshots/` | terminal screenshots |
| `report.md` | the 1 page report |

Q1 and Q2 are kept in separate trees on purpose: with lazy allocation (Q2)
`sbrk(4*4096)` no longer allocates anything, so the "4 new pages" demo in Q1
only works on the eager version.

Every change in the kernel files is marked with a `Q1` / `Q2` comment.

## Running

```
cd q1_page_table
make qemu-nox        # then run:  pttest
cd ../q2_lazy_alloc
make qemu-nox        # then run:  faulttest
cd ../q3_page_replacement
make qemu-nox        # then run:  pagerepl 3 7 0 1 2 0 3 0 4 2 3 0 3 2 1 2 0 1 7 0 1
                     #       and: pagerepl table 7 0 1 2 0 3 0 4 2 3 0 3 2 1 2 0 1 7 0 1
```

Note: newer gcc gives `-Werror=array-bounds` errors in mp.c, so I changed
`-Werror` to `-Wno-error` in the Makefiles.

`pagerepl.c` also compiles on a normal machine: `gcc -DHOST -o pagerepl_host pagerepl.c`
