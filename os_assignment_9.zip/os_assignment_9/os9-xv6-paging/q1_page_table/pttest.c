#include "types.h"
#include "stat.h"
#include "user.h"

// Q1 test: dump the page table, grow the heap by 4 pages, dump again.
int
main(int argc, char *argv[])
{
  int before, after;

  printf(1, "=== at start ===\n");
  before = vmprint();

  sbrk(4 * 4096);

  printf(1, "=== after sbrk(4*4096) ===\n");
  after = vmprint();

  printf(1, "new pages: %d\n", after - before);
  exit();
}
