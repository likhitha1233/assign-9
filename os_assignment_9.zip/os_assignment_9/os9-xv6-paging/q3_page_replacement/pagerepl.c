// Q3: FIFO vs LRU page replacement
//
// usage:  pagerepl <frames> <ref1> <ref2> ...     run both, print every step
//         pagerepl table <ref1> <ref2> ...        compare for 3, 4 and 5 frames
//
// Same file also builds on a normal linux box for quick testing:
//   gcc -DHOST -o pagerepl_host pagerepl.c

#ifdef HOST
#include <stdio.h>
#include <stdlib.h>
#define out(...) printf(__VA_ARGS__)
#define quit(c) exit(c)
#else
#include "types.h"
#include "stat.h"
#include "user.h"
#define out(...) printf(1, __VA_ARGS__)
#define quit(c) exit()        // xv6 exit() takes no argument
#endif

#define MAXF 16
#define MAXR 128

int refs[MAXR];
int nrefs;

void
printframes(int *frames, int nf)
{
  int i;
  out("[");
  for(i = 0; i < nf; i++){
    if(frames[i] < 0)
      out(" -");
    else
      out(" %d", frames[i]);
  }
  out(" ]");
}

// verbose = 1 prints every reference, 0 just returns the fault count
int
fifo(int nf, int verbose)
{
  int frames[MAXF];
  int i, j, faults = 0;
  int next = 0;           // slot that gets replaced next (oldest page)

  for(i = 0; i < nf; i++)
    frames[i] = -1;

  for(i = 0; i < nrefs; i++){
    int hit = 0;
    for(j = 0; j < nf; j++)
      if(frames[j] == refs[i])
        hit = 1;

    if(!hit){
      frames[next] = refs[i];
      next = (next + 1) % nf;
      faults++;
    }
    if(verbose){
      out("ref %d  ", refs[i]);
      printframes(frames, nf);
      out("  %s\n", hit ? "HIT" : "FAULT");
    }
  }
  return faults;
}

int
lru(int nf, int verbose)
{
  int frames[MAXF];
  int last[MAXF];         // "time" each frame was last used
  int i, j, faults = 0;

  for(i = 0; i < nf; i++){
    frames[i] = -1;
    last[i] = -1;
  }

  for(i = 0; i < nrefs; i++){
    int hit = -1;
    for(j = 0; j < nf; j++)
      if(frames[j] == refs[i])
        hit = j;

    if(hit >= 0){
      last[hit] = i;      // refresh
    } else {
      // pick empty frame if any, else the one used longest ago
      int victim = 0;
      for(j = 0; j < nf; j++){
        if(frames[j] < 0){
          victim = j;
          break;
        }
        if(last[j] < last[victim])
          victim = j;
      }
      frames[victim] = refs[i];
      last[victim] = i;
      faults++;
    }
    if(verbose){
      out("ref %d  ", refs[i]);
      printframes(frames, nf);
      out("  %s\n", hit >= 0 ? "HIT" : "FAULT");
    }
  }
  return faults;
}

// prints x/y as a percentage with 2 decimals (xv6 printf has no floats)
void
printpct(int x, int y)
{
  int v = x * 10000 / y;
  out("%d.%d%d%%", v / 100, (v / 10) % 10, v % 10);
}

int
main(int argc, char *argv[])
{
  int i, nf, f1, f2, start, table = 0;

  if(argc < 3){
    out("usage: pagerepl <frames> <ref string...>\n");
    out("       pagerepl table <ref string...>\n");
    quit(1);
  }

  if(argv[1][0] == 't'){
    table = 1;
    start = 2;
  } else {
    nf = atoi(argv[1]);
    if(nf < 1 || nf > MAXF){
      out("frames must be between 1 and %d\n", MAXF);
      quit(1);
    }
    start = 2;
  }

  nrefs = 0;
  for(i = start; i < argc && nrefs < MAXR; i++)
    refs[nrefs++] = atoi(argv[i]);

  if(!table){
    out("---- FIFO, %d frames ----\n", nf);
    f1 = fifo(nf, 1);
    out("FIFO page faults: %d\n\n", f1);

    out("---- LRU, %d frames ----\n", nf);
    f2 = lru(nf, 1);
    out("LRU page faults: %d\n", f2);
  } else {
    out("references: %d\n", nrefs);
    out("frames  FIFO faults  FIFO hit ratio  LRU faults  LRU hit ratio\n");
    for(nf = 3; nf <= 5; nf++){
      f1 = fifo(nf, 0);
      f2 = lru(nf, 0);
      out("%d       %d            ", nf, f1);
      printpct(nrefs - f1, nrefs);
      out("          %d          ", f2);
      printpct(nrefs - f2, nrefs);
      out("\n");
    }
  }

  quit(0);
}
