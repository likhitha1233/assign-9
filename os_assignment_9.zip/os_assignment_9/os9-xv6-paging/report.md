# OS Assignment 9 - Report

**Likhitha Vijaya Kumar (2403MC05)**

## Q1 - vmprint()
Added syscall `vmprint()` (number 22). `sys_vmprint()` in sysproc.c calls
`vmprint_pgdir()` which I wrote in vm.c, with the same loop shape as
`freevm()`: go through the page directory entries below `KERNBASE`, and for
each present PDE go through its 1024 PTEs. For each present user page it
prints the virtual address, physical address and the P/W/U bits. At the end it prints
the number of valid user pages and the number of page-table pages (1 directory + one per used PDE).
The stack guard page is present but has U cleared by `exec`, so it is not counted as a user page.
`pttest.c` calls it, does `sbrk(4*4096)`, calls it again. The second dump has exactly 4 more
pages (heap pages, all P=1 W=1 U=1) and the difference is printed.

## Q2 - Lazy allocation
- `sys_sbrk()`: for n > 0 it only does `sz += n` (after checking it stays below KERNBASE). n < 0 still calls `growproc()`.
- `copyuvm()` used to panic on missing pages, it now skips them (`continue`). `deallocuvm()` already skipped non-present PTEs, I just commented it.
- `trap.c`: new `case T_PGFLT`. If the fault is from user mode, the page was not present, and `rcr2() < sz`, it does `kalloc()`, `memset` to 0, `mappages(... PTE_W|PTE_U)`, increments the new `pgfaults` field in `struct proc`, and returns so the instruction re-runs. Otherwise it prints pid + address and sets `killed`.
- `mappages()` was static, made it non-static + added to defs.h.
- `getfaults()` syscall returns `p->pgfaults`.

`faulttest.c`: `sbrk(32*4096)`, writes to pages 0, 3, 7, 15, 31, prints the fault count, which should be 5
(the other 27 pages are never touched so no memory is used for them). Writing again to a page that is
already mapped does not add a fault. A forked child then writes at `sz` + 100; it gets killed with the
segfault message, and the parent carries on and prints that it is still alive.

Limitation: system calls like read() into a lazy page do not fault, copyout just fails, because the kernel walks the page table itself.

## Q3 - FIFO vs LRU
`pagerepl.c` takes frames + reference string on the command line. It prints the frames after each reference
and HIT / FAULT. FIFO keeps a pointer to the oldest frame, LRU keeps a last-used time per frame and evicts the smallest.
For the given string with 3 frames: **FIFO = 15 faults, LRU = 12 faults** (matches expected).

| frames | FIFO faults | FIFO hit ratio | LRU faults | LRU hit ratio |
|---|---|---|---|---|
| 3 | 15 | 25.00% | 12 | 40.00% |
| 4 | 10 | 50.00% | 8 | 60.00% |
| 5 | 9 | 55.00% | 7 | 65.00% |

LRU is better at every frame count here, and more frames means fewer faults for both.
